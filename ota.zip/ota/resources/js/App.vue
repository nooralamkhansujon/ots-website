<template>
    <Header/>
     <div class="row">
         <div class="col-md-3">
               <sidebar/>
         </div>
         <div class="col-md-9">
            <div id="main" class="mx-2">
                <Flights/>
            </div>
         </div>
     </div>
    <Footer/>
</template>


<script>
import Flights from './pages/Flights.vue';
import Header from './components/Header.vue'
import Footer from './components/Footer.vue';
import Sidebar from './components/Sidebar';

export default {
    components:{
        Flights,
        Header,Footer,Sidebar
    }
}
</script>

<style >
   body{
    font-family: 'Roboto Condensed', sans-serif
   }

</style>