<template>
 <header id="header">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="img/primary.png" alt="">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">Flights</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">Hotels</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Cars</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Tours & activities</a>
                        </li>
                    
                         <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                          About Online Travel Services
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">About us</a></li>
                            <li><a class="dropdown-item" href="#">Ots owners</a></li>
                            <li><a class="dropdown-item" href="#">Travel Condition</a></li>
                            <li><a class="dropdown-item" href="#">Privacy Policy</a></li>
                            <li >
                               <a  class="dropdown-item" href="#">Cookies</a>
                           </li>
                            </ul>
                        </li>
                         <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                              Support
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Contact us</a></li>
                            <li><a class="dropdown-item" href="#">FAQ</a></li>
                            <li><a class="dropdown-item" href="#">Cancellation protection</a></li>
                            <li>
                                <a class="dropdown-item" href="#">
                                   Airline Information
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="#">
                                   My Bookinga
                                </a>
                            </li>
                            </ul>
                        </li>
                </ul>
            </div>
            </div>
    </nav>

 </header>
</template>

<script>
export default {
   data(){
       return {
           
       }
   }
}
</script>


<style scoped>
    #header{
        border-bottom:10px solid rgb(150, 116, 39);
        box-shadow: 2px 5px 10px rgba(0,0,0,0.3);
    }
    .navbar{
        background-color:#f7d27e !important;
    }
    .navbar-brand img{
        width:200px;
    }
    .nav-item{
         margin:0 10px;
         padding:5px;
         border-radius:5px;
         transition: all .5s ease;
    }
    .nav-link{
        color:#017A93 !important;
        font-size:16px;
        text-transform: uppercase !important;
    }
    .nav-item:hover .nav-link,.dropdown-menu  li:hover .dropdown-item{
        color:#fff !important;
    }
    .nav-item:hover,.dropdown-menu  li:hover .dropdown-item{
        background-color:#f5ad06 !important;
    }
    .dropdown .dropdown-menu{
        color:#017A93 !important;
        background-color:#f7d27e !important;
    }
</style>