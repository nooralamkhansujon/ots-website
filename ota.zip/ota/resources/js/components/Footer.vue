<template>
   <footer id="footer" class="container">
        <h1>Footer Section </h1>
   </footer>
</template>