<template>
        <aside class="sidebar mt-3 ml-2">
              <div class="sidebar-header">
                  <h2>Travel update</h2>
                  <p>Actions for safe travel</p>
              </div>
              <div class="sidebar-body">
                  <div class="notice-board-section">
                      <!-- single notice board -->
                     <div class="notice-board">
                        <div class="notice-board-heading">
                             <h4>2021 Annual General Meetting</h4>
                             <p>(ots office)</p>
                        </div>
                        <div class="notice-board-invite">
                             Join us for a gathering to discuss
                             Business Development for eCommerce industry
                        </div>
                        <div class="notice-board-duration">
                              <span class="date">wednesday,9th of October 2021</span> <br>
                              <span class="duration">10:00AM - 4 PM</span>
                        </div>
                         <div class="notice-board-address">
                            Concord Grand 4th floor,169/1,shantinagar,dhaka 1217
                         </div>
                         <div class="notice-board-reason-person">
                             <p>
                                <span>John Doe</span> <br>
                                <span class="designation">Executive officer</span>
                             </p>
                             <p>
                                <span>karim do</span> <br>
                                <span class="designation">Executive officer</span>
                             </p>
                         </div>
                     </div>
                     <!-- end of single notice board -->
                  </div>
              </div>
        </aside>
</template>

<script>
export default {
    
}
</script>

<style scoped>
  .sidebar{
      background:rgb(205, 231, 227);
      width:100%;
      height:auto;
    }
    .sidebar-header{
        background:linear-gradient(to bottom,#f7d27e,#BE8D16);
        color:#00778C;
        width:100%;
    }
    .sidebar-body .notice-board-section{
        display: flex;
        justify-content: center;
    }
    .sidebar-header h2{
        font-size:25px;
        text-align: center;
    }
    .sidebar-header p{
        color:#fff;
        text-align: center;
    }
    .notice-board{
        color:#fff;
        border-radius: 15px;
        background:linear-gradient(to right,#5A21AD,#753ec9);
        text-align:center;
        width:80%;
    }
    .notice-board-heading{
         background:linear-gradient(to bottom, #967427,#D0A337); 
         border-radius: 15px;
    }
    .notice-board-heading:hover{
        box-shadow: 2px 5px 10px rgba(0,0,0,0.3);
    }
    .notice-board-heading p{
        color:#00778C;
        text-transform: capitalize;
    }
    .notice-board-reason-person{
        display:flex;
        justify-content: center;
        background:linear-gradient(to bottom, #967427,#D0A337); 
         border-radius: 15px;
        
    }
    .notice-board-reason-person:hover{
        box-shadow: 2px -5px 10px rgba(0,0,0,0.3);
    }
    .notice-board-reason-person p{
        margin:5px;
    }
    .notice-board-invite{
         color:#fff;
         padding:10px;
         text-transform: uppercase;
    }
    .notice-board-duration .duration{
        background:#BE8D16;
        border:1px solid #BE8D16;
        padding:5px;
        margin:0 10px;
        display:inline-block;
    }
   .notice-board-address{
       margin:10px;
       text-transform: capitalize;
   }    
    
</style>