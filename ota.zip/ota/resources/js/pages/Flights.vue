<template>
    <div class="search-banner mt-3">
        <img src="/img/flights.jpg" alt="">
        <div class="search-form-content">
            <form class="search-form">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12"> 
                            <div class="form-check">
                                <div class="radio">
                                    <input class="form-check-input" type="radio" name="exampleRadios"  value="option1" >
                                    <label class="form-check-label" >Return
                                    </label>
                                </div>
                                <div class="radio">
                                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                    <label class="form-check-label" for="exampleRadios1">
                                    One-way
                                    </label>
                                </div>  
                                <div class="radio">
                                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                    <label class="form-check-label" for="exampleRadios1">
                                    Multi-City
                                    </label>
                                </div>
                            </div>
                        </div>
                        <!-- end of col-md 12   -->

                        <!-- col-md-6 -->
                        <div class="col-md-6">
                        <!-- <component :is="componentId"></component> -->
                            <div class="input-group mb-3">
                                <span class="input-group-text" id="basic-addon1"><i class="fas fa-plane-departure"></i></span>
                                <input type="text" class="form-control" placeholder="From" >
                            </div>`
                        </div>
                        <!-- end of col-md-6  -->
                            
                        <!-- col-md-6 -->
                        <div class="col-md-6">
                            <div class="input-group mb-3">
                                <span class="input-group-text">
                                    <i class="fas fa-plane-arrival"></i></span>
                                <input type="text" class="form-control" placeholder="To" >
                            </div>`
                        </div>
                        <!-- end of col-md-6  -->

                        <!-- col-md-3 -->
                        <div class="col-md-3">
                            <div class="input-group mb-3">
                                <span class="input-group-text">
                                <i class="fas fa-calendar-day"></i></span>
                                <input type="datetime" v-model="departureDate" class="form-control" readonly ref="departure-date" placeholder="Departure">
                               
                            </div>
                        </div>
                        <!-- end of col-md-3  -->
                        <!-- col-md-3 -->
                        <div class="col-md-3">
                            <div class="input-group mb-3">
                                <span class="input-group-text">
                                <i class="fas fa-calendar-minus"></i>
                                </span>
                                <input ref="arrival-input" v-model="arrivalDate" readonly type="datetime" class="form-control" placeholder="arrival" >
                            </div>`
                        </div>
                        <!-- end of col-md-3  -->
                        <!-- col-md-3 -->
                        <div class="col-md-3">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="input-group mb-3">
                                        <span class="input-group-text">
                                        <i class="fas fa-user"></i>
                                        </span>
                                     
                                     </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="input-group mb-3">
                                        <span class="input-group-text">
                                          <i class="fas fa-child"></i>
                                        </span>
                                       
                                        <Multiselect
                                            v-model="value"
                                            :options="options"
                                         />
                                     </div>
                                </div>
                            </div>
                        </div>
                        <!-- end of col-md-3  -->
                    </div> 
                </div>
           </form>
        </div>
    </div>
</template>

<script>
  import Multiselect from '@vueform/multiselect'
export default {
    components:{
     Multiselect
    },
    data(){
        return {
            home:"jakir khan are you sure",
            roundtrip:"",
            arrivalDate:"",
            departureDate:"",
            value:1,
            options: [
            'Batman',
            'Robin',
            'Joker',
            ]
        }

    },
    mounted(){
        console.log(this.$refs['departure-date']);
        var input      = this.$refs['departure-date'];
        let self       = this;
        var datepicker = new HotelDatepicker(input,{
            format: 'DD/MM/YYYY',
            minNights: 2,
            maxNights:10,
            selectForward:true,
            onSelectRange() {
                console.log('Date range selected!');
                console.log(self.$refs['departure-date'].value);
                self.roundtrip     = self.$refs['departure-date'].value;
                self.departureDate = self.roundtrip.split('-')[0].trim();
                self.arrivalDate   = self.roundtrip.split('-')[1].trim();
             }
        });
        console.log(datepicker.getValue());
        console.log(this.roundtrip);
    }
}
</script>

<style scoped>
    .search-banner{
        position:relative;
        height:auto !important;
    }
    .search-banner img{
        height:700px;
        max-height: 100vh !important;
        width:100%;
    }
  
    .search-form-content{
        background-color:rgb(243, 212, 140,0.9);
        position:absolute;
        bottom:0;
        right:0;
        left:0;
        height:60%;
        width:100%;
        /* max-height:100%; */
    }
    @media   screen and (max-width:992px) {
        .search-form-content{
            height:100%;
        }
    }
    .form-check {
        display:flex;
    }
    .form-check .radio{
        margin:10px !important;
        padding:10px;
    }
    .form-check .radio input[type=radio] {
        color:#053e64 !important;
        background:#16547C !important;
    }
    .form-check-label {
        color:#fff;
    }
</style>